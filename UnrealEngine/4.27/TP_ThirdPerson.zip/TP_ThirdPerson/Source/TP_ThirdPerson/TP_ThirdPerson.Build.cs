// Copyright Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;

public class TP_ThirdPerson : ModuleRules
{
	public TP_ThirdPerson(ReadOnlyTargetRules Target) : base(Target)
	{
#if false
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[] { "Core", "CoreUObject", "Engine", "InputCore", "HeadMountedDisplay" });
#endif

		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		
		PrivatePCHHeaderFile = "TP_ThirdPerson_PCH.h";
		
		PublicDependencyModuleNames.AddRange(new string[] {
			//-- external --
			"fmt"
			
			// --- App ---
            , "ApplicationCore"
			, "Projects"

			// --- Rendering ---
            , "RenderCore"
            , "RHI"
			, "Niagara"
			// --- UMG / Slate ---
			, "Slate"
			, "SlateCore"
			, "UMG"
			// --- Default ---
			, "Core"
			, "CoreUObject"
			, "Engine"
			, "InputCore"
// 			, "EnhancedInput"
			, "HeadMountedDisplay"
		});
		
		PublicIncludePaths.AddRange(
			new string[] {
/*
				//-- Common --
				Path.Combine(ModuleDirectory, "MyLib")
				,Path.Combine(ModuleDirectory, "Misc")
				,Path.Combine(ModuleDirectory, "Tests")

				//-- Weeks --
				,Path.Combine(ModuleDirectory, "Week001") //"TP_MyThirdPerson/Week001"
*/
			}
		);
		
		
		if (Target.bBuildEditor == true) {
			PrivateDependencyModuleNames.AddRange(new string[] {
				"UnrealEd"
				, "MainFrame"
			});
		}
	}
}
