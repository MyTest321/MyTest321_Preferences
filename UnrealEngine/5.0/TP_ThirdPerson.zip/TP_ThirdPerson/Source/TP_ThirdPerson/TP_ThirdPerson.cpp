// Copyright Epic Games, Inc. All Rights Reserved.

#include "TP_ThirdPerson.h"
#include "Modules/ModuleManager.h"

#if WITH_EDITOR
	#include "Interfaces/IMainFrameModule.h"
#endif // WITH_EDITOR

#define LOCTEXT_NAMESPACE "TP_ThirdPerson_Module"
DEFINE_LOG_CATEGORY(LogTP_ThirdPerson_Module);

class TP_ThirdPerson_Module : public IModuleInterface
{
	using ThisClass = TP_ThirdPerson_Module;

public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

private:
#if WITH_EDITOR
	void OnEditorStartup();
	void OnEditorMainFrameStartup();
#endif // WITH_EDITOR
};

inline void TP_ThirdPerson_Module::StartupModule()
{
#if WITH_EDITOR
	OnEditorStartup();
#endif // WITH_EDITOR
}

#if WITH_EDITOR
void TP_ThirdPerson_Module::OnEditorStartup()
{
	IMainFrameModule& MainFrameModule = IMainFrameModule::Get();
	if (MainFrameModule.IsWindowInitialized())
	{
		OnEditorMainFrameStartup();
	}
	else
	{
		MainFrameModule.OnMainFrameCreationFinished().AddLambda(
			[this](TSharedPtr<SWindow> InRootWindow, bool bIsRunningStartupDialog) {
				OnEditorMainFrameStartup();
			}
        );
	}
}

void TP_ThirdPerson_Module::OnEditorMainFrameStartup()
{
	// limit the fps to avoid burning my GPU in editor during development
    auto* V = IConsoleManager::Get().FindConsoleVariable(TEXT("t.MaxFPS"));
	if (V)
	{
        V->Set(60);
	} else {
        UE_LOG(LogTP_ThirdPerson_Module, Error, TEXT("Console variable t.MaxFPS not found"));
    }

	// show fps
    if (GEditor) {
        if (auto* World = GEditor->GetEditorWorldContext().World())
        {
            GEditor->Exec(World, TEXT("stat fps"));
        }
    }
}
#endif // WITH_EDITOR

void TP_ThirdPerson_Module::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

//IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TP_ThirdPerson, "TP_ThirdPerson" );
IMPLEMENT_PRIMARY_GAME_MODULE(TP_ThirdPerson_Module, TP_ThirdPerson, "TP_ThirdPerson");
 