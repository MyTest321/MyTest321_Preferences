#pragma once

#include "Runtime/Launch/Resources/Version.h"

#if ENGINE_MAJOR_VERSION == 5
    #define IS_UE5 1
    #define IS_UE4 0
	
	#if ENGINE_MINOR_VERSION >= 3
		#define IS_UE5_3 1
	#endif
	
#elif ENGINE_MAJOR_VERSION == 4
    #define IS_UE5 0
    #define IS_UE4 1
#else
    #error "Unsupported Unreal Engine version!"
#endif
